
package example.hello;
	
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
	
public class Server implements Hello {

    private String msg;

    public Server( String msg ) {
	this.msg = msg;
    }

    public String sayHello() {
	return "Hello world: " + msg;
    }
	
    public static void main(String args[]) {
	
	try {
	    Server obj = new Server( "Coucou" );
	    Hello stub = (Hello) UnicastRemoteObject.exportObject( obj, 0 );

	    // Bind the remote object's stub in the registry
	    // Registry registry = LocateRegistry.getRegistry();
	    Registry registry = LocateRegistry.createRegistry( 5000 );
	    registry.bind( "Hello", stub );

	    System.err.println( "Server ready" );

	    try {
		Thread.currentThread().sleep( 360000 );
	    } catch( Exception e ){}

	} catch( Exception e ) {

	    System.err.println("Server exception: " + e.toString());
	    e.printStackTrace();
	}
    }
}
