
#define PORT_NUM 8888

int initialization();
int connection(int socket_desc);
int close(int sock);
