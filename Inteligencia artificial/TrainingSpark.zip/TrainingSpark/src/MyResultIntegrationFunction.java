
import org.apache.spark.api.java.function.Function2;

public class MyResultIntegrationFunction implements Function2<String, String, String>
{


    public String call(String rddOutputElementA,
                       String rddOutputElementB)
    {
        double[] connectionStrengthsA;
        double[] connectionStrengthsB;
        double weight;
        Double doubleObject;
        String connectionStrengths;
        //
        connectionStrengthsA = DataFormat.getArrayOfDoubles(rddOutputElementA);
        connectionStrengthsB = DataFormat.getArrayOfDoubles(rddOutputElementB);
        connectionStrengths = "";
        for(int i=0; i < connectionStrengthsA.length; i++)
        {
            weight = connectionStrengthsA[i] + connectionStrengthsB[i];
            doubleObject = new Double(weight);
            connectionStrengths = connectionStrengths + doubleObject.toString() + ",";
            doubleObject = null;
        }//end for
        connectionStrengths = DataFormat.removeLastChar(connectionStrengths);
        return connectionStrengths;
    }//end call

}//end class