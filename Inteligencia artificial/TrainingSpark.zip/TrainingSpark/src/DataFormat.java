/*

DataFormat
String data manipulation

by Gerardo Ayala.
UDLAP
February 2019.

*/
public abstract class DataFormat
{


    private static String removeBlanks(String aString)
    {
        String cleanString;
        //
        cleanString = aString;
        cleanString = aString.replaceAll(" ", "");
        return cleanString;
    }//end removeBlanks



    public static String[] split(String aString)
    {
        String cleasString;
        String[] arrayOfStrings;
        //
        cleasString = removeBlanks(aString);
        arrayOfStrings = cleasString.split("/");
        return arrayOfStrings;
    }//end splitData



    public static String removeLastChar(String aString)
    {
        return aString.substring(0,aString.length()-1);
    }//end removeLastCharacter



    public static double[] getArrayOfDoubles(String stringData)
    {
        double[] arrayOfDoubles;
        String[] stringDataArray;
        Double doubleObject;
        //
        stringDataArray = stringData.split(",");
        arrayOfDoubles = new double[stringDataArray.length];
        for(int i=0; i<stringDataArray.length;i++)
        {
            doubleObject = new Double(stringDataArray[i]);
            arrayOfDoubles[i] = doubleObject.doubleValue();
            doubleObject = null;
        }//end for
        return arrayOfDoubles;
    }//end getArrayOfDoubles



    public static int[] getArrayOfInts(String aString)
    {
        int[] arrayOfInts;
        String[] data;
        //
        data = aString.split(",");
        arrayOfInts = new int[data.length];
        for(int i=0; i<data.length;i++)
        {
            arrayOfInts[i] = new Integer(data[i]).intValue();
        }//end for
        return arrayOfInts;
    }//end getArrayOfInts



}//end DataFormat
