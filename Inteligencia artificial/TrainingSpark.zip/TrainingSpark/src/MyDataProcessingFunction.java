

import org.apache.spark.api.java.function.Function;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MyDataProcessingFunction implements Function<String, String>
{




    public String call(String rddElement)
    {
        String connectionStrengths;
        int[] inputPattern;
        int[] outputPattern;
        double weight;
        Double doubleObject;
        String[] trainingPattern;
        //
        // 0.0625 = 1/16
        // excitation adjustment = + 0.625
        // inhibition adjustment = - 0.625
        double adjustment = 0.000020345052083;


        trainingPattern = DataFormat.split(rddElement);
        inputPattern = DataFormat.getArrayOfInts(trainingPattern[0]);
        outputPattern = DataFormat.getArrayOfInts(trainingPattern[1]);
        trainingPattern = null;
        //
        connectionStrengths = "";
        for(int i = 0; i < 4; i++)
        {
            for(int j = 0; j < 4; j++)
            {
                weight = (inputPattern[j] * outputPattern[i]) * adjustment;
                doubleObject = new Double(weight);
                connectionStrengths = connectionStrengths + doubleObject.toString() + ",";
                doubleObject = null;
            }//end for
        }//end for;
        inputPattern = null;
        outputPattern = null;
        connectionStrengths = DataFormat.removeLastChar(connectionStrengths);
        return connectionStrengths;
    }//end call

}//end class

