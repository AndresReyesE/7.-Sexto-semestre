package Observer;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Subject extends Remote {

}
